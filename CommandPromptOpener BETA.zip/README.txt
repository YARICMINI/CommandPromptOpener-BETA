This application launches the Command Prompt.

That is , the file cmd.exe.